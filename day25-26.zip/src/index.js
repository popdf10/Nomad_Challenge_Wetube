import express from "express";
import request from "request";

const app = express();

// Codesanbox does not need PORT :)
app.listen(() => console.log(`Listening!`));
